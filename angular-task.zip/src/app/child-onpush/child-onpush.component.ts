import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-child-onpush',
  templateUrl: './child-onpush.component.html',
  styleUrls: ['./child-onpush.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChildOnpushComponent {
  @Input() primitiveData!: number;
  @Input() nonPrimitiveData!: { value: string };
  ownData: string = 'Initial Child Data';
  
  updateOwnData() {
    this.ownData = 'Updated ' + new Date().toISOString();
  }
}
