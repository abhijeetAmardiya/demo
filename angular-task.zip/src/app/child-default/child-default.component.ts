import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-child-default',
  templateUrl: './child-default.component.html',
  styleUrls: ['./child-default.component.scss']
})
export class ChildDefaultComponent {
  @Input() primitiveData!: number;
  @Input() nonPrimitiveData!: { value: string };
  ownData: string = 'Initial Child Data';
  
  updateOwnData() {
    this.ownData = 'Updated ' + new Date().toISOString();
  }
}
