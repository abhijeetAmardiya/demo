import { Component } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.scss']
})
export class ParentComponent {
  primitiveData: number = 0;
  nonPrimitiveData: { value: string } = { value: 'Initial' };

  updatePrimitiveData() {
    this.primitiveData++;
  }

  updateNonPrimitiveData() {
    this.nonPrimitiveData.value = 'Updated ' + new Date().toISOString();
  }
}
