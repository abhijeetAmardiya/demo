import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ParentComponent } from './parent/parent.component';
import { ChildOnpushComponent } from './child-onpush/child-onpush.component';
import { ChildDefaultComponent } from './child-default/child-default.component';

@NgModule({
  declarations: [
    AppComponent,
    ParentComponent,
    ChildOnpushComponent,
    ChildDefaultComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
